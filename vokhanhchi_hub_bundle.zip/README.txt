GITHUB PAGES SETUP

1. Upload this folder's contents to the ROOT of your chivokhanh321.github.io repository.
2. Upload your aquarium website's files into the aquarium/ folder.
   The aquarium main page must be aquarium/index.html.
3. The CV is already in cv/index.html with its image in cv/assets/profile.jpg.
4. Commit changes and wait for GitHub Pages to deploy.

Expected URLs:
- Homepage: https://chivokhanh321.github.io/
- Aquarium: https://chivokhanh321.github.io/aquarium/
- CV: https://chivokhanh321.github.io/cv/
